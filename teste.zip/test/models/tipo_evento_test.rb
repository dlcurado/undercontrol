require 'test_helper'

class TipoEventoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
