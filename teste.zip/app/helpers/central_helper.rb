module CentralHelper
end
