class Local < ApplicationRecord
end
