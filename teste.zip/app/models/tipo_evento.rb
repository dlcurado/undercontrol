class TipoEvento < ApplicationRecord
	has_many :eventos
end
