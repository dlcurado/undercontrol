class CentralController < ApplicationController
  def index
  end
end
